# Perfume Android App

- App name: **Perfume**
- Brand/logo: **Mushk Mehboob Mahal**
- HTML interface and local data are bundled in the app.
- Android WebView bridge handles browser-style file downloads, image/JSON exports, file-picker restore, and printing.

## Build
GitHub Actions runs the build on pushes to `main`/`master` or manually via **Actions → Build Perfume APK → Run workflow**.
Download `Perfume-APK` from the completed workflow run's Artifacts section.
